Multi-Transform
===============
.. note::
   Only fully independent transforms can be executed in parallel.

.. doxygenfile:: spfft/multi_transform.h
   :project: SpFFT

.. doxygenfile:: spfft/multi_transform_float.h
   :project: SpFFT
