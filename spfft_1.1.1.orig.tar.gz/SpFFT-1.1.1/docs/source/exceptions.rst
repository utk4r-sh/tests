Exceptions
==========

.. doxygenfile:: spfft/exceptions.hpp
   :project: SpFFT
