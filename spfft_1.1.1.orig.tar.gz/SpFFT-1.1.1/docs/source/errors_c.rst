Errors
======

.. doxygenfile:: spfft/errors.h
   :project: SpFFT
