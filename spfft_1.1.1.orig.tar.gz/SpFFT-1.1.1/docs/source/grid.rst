Grid
====
.. note::
   A Grid object can be safely destroyed after Transform objects have been created, since internal reference counting used to prevent the release of resources while still in use.

.. doxygenclass:: spfft::Grid
   :project: SpFFT
   :members:
