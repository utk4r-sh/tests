Types
=====

.. doxygenfile:: spfft/types.h
   :project: SpFFT
