Grid
====

.. note::
   A Grid handle can be safely destroyed after Transform handles have been created, since internal reference counting used to prevent the release of resources while still in use.

.. doxygenfile:: spfft/grid.h
   :project: SpFFT
